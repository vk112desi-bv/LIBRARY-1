import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Send, 
  CheckCircle2, 
  Phone, 
  MessageCircle, 
  Printer, 
  Clock, 
  Calendar, 
  User, 
  BookOpen, 
  ShieldCheck,
  AlertCircle,
  RotateCcw
} from 'lucide-react';
import { RegistrationFormData, SavedRegistration } from '../types';
import { LIBRARY_INFO } from '../data/libraryData';

interface RegistrationFormProps {
  initialPlan?: 'Half Day – ₹400' | 'Full Day – ₹600';
  onPlanConsumed?: () => void;
}

export const RegistrationForm: React.FC<RegistrationFormProps> = ({
  initialPlan,
  onPlanConsumed,
}) => {
  const [formData, setFormData] = useState<RegistrationFormData>({
    fullName: '',
    mobile: '',
    email: '',
    dob: '',
    gender: '',
    occupation: '',
    examPurpose: '',
    plan: 'Full Day – ₹600',
    startDate: new Date().toISOString().split('T')[0],
    preferredTiming: 'Full Day',
    heardFrom: '',
    message: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submittedReceipt, setSubmittedReceipt] = useState<SavedRegistration | null>(null);
  const [savedSubmissions, setSavedSubmissions] = useState<SavedRegistration[]>([]);
  const [showHistoryModal, setShowHistoryModal] = useState(false);

  // Auto-sync initialPlan if prop changes
  useEffect(() => {
    if (initialPlan) {
      setFormData((prev) => ({ ...prev, plan: initialPlan }));
      if (initialPlan === 'Half Day – ₹400') {
        setFormData((prev) => ({ ...prev, preferredTiming: 'Morning' }));
      } else {
        setFormData((prev) => ({ ...prev, preferredTiming: 'Full Day' }));
      }
      onPlanConsumed?.();
    }
  }, [initialPlan, onPlanConsumed]);

  // Load saved registrations from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem('aadhay_library_registrations');
      if (stored) {
        setSavedSubmissions(JSON.parse(stored));
      }
    } catch {
      // ignore
    }
  }, []);

  const validate = (): boolean => {
    const errs: Record<string, string> = {};

    if (!formData.fullName.trim()) {
      errs.fullName = 'Full Name is required';
    }

    const cleanMobile = formData.mobile.replace(/\D/g, '');
    if (!cleanMobile) {
      errs.mobile = 'Mobile Number is required';
    } else if (cleanMobile.length < 10) {
      errs.mobile = 'Please enter a valid 10-digit mobile number';
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errs.email = 'Please enter a valid email address';
    }

    if (!formData.plan) {
      errs.plan = 'Please select a membership plan';
    }

    if (!formData.startDate) {
      errs.startDate = 'Please select a preferred start date';
    }

    if (!formData.preferredTiming) {
      errs.preferredTiming = 'Please select a preferred timing';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const receiptId = `ADH-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newSubmission: SavedRegistration = {
      ...formData,
      id: receiptId,
      submittedAt: new Date().toLocaleString('en-IN', {
        timeZone: 'Asia/Kolkata',
        dateStyle: 'medium',
        timeStyle: 'short',
      }),
      status: 'Pending Verification',
    };

    const updatedList = [newSubmission, ...savedSubmissions];
    setSavedSubmissions(updatedList);
    try {
      localStorage.setItem('aadhay_library_registrations', JSON.stringify(updatedList));
    } catch {
      // ignore
    }

    setSubmittedReceipt(newSubmission);
  };

  const handleReset = () => {
    setFormData({
      fullName: '',
      mobile: '',
      email: '',
      dob: '',
      gender: '',
      occupation: '',
      examPurpose: '',
      plan: 'Full Day – ₹600',
      startDate: new Date().toISOString().split('T')[0],
      preferredTiming: 'Full Day',
      heardFrom: '',
      message: '',
    });
    setErrors({});
    setSubmittedReceipt(null);
  };

  const formatWhatsAppMessage = (item: SavedRegistration): string => {
    const text = `*AADHAY LIBRARY REGISTRATION*
--------------------------------
*Reg ID:* ${item.id}
*Name:* ${item.fullName}
*Mobile:* ${item.mobile}
*Plan:* ${item.plan}
*Timing:* ${item.preferredTiming}
*Start Date:* ${item.startDate}
*Exam Target:* ${item.examPurpose || 'Not specified'}
*Occupation:* ${item.occupation || 'Student'}
--------------------------------
Hello Management, I have submitted my registration online. Please confirm my seat availability.`;

    return `https://wa.me/91${LIBRARY_INFO.phone}?text=${encodeURIComponent(text)}`;
  };

  return (
    <section id="register-section" className="py-12 lg:py-16 bg-white border-b border-slate-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center space-x-1 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-widest mb-3 border border-indigo-100">
            <FileText className="w-3.5 h-3.5 mr-1" />
            <span>INSTANT SEAT RESERVATION</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight">
            Library Membership Registration Form
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Please fill in the details below to register for membership. Our team will contact you regarding seat availability, membership plan and payment details.
          </p>

          {savedSubmissions.length > 0 && !submittedReceipt && (
            <div className="mt-4">
              <button
                type="button"
                onClick={() => setShowHistoryModal(true)}
                className="text-xs text-indigo-700 font-bold hover:underline inline-flex items-center"
              >
                <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-emerald-600" />
                View your previous submissions ({savedSubmissions.length})
              </button>
            </div>
          )}
        </div>

        {/* Success Confirmation Receipt State */}
        {submittedReceipt ? (
          <div className="bg-slate-50 border-2 border-indigo-600 rounded-2xl p-6 sm:p-8 shadow-xl animate-fadeIn">
            <div className="text-center mb-6">
              <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto mb-3 shadow-xs">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900">
                Registration Submitted Successfully!
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                Your admission request has been logged. Our library coordinator will verify seat availability.
              </p>
            </div>

            {/* Receipt Summary Card */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 mb-6 shadow-xs">
              <div className="flex flex-wrap justify-between items-center pb-4 border-b border-slate-100 gap-2">
                <div>
                  <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block">Registration Number</span>
                  <span className="text-lg font-black text-indigo-700 font-mono">{submittedReceipt.id}</span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block">Status</span>
                  <span className="inline-block px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900">
                    {submittedReceipt.status}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4 text-xs sm:text-sm border-b border-slate-100">
                <div>
                  <span className="text-slate-500 font-medium">Applicant Name:</span>
                  <p className="font-bold text-slate-900">{submittedReceipt.fullName}</p>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Contact Phone:</span>
                  <p className="font-bold text-slate-900">{submittedReceipt.mobile}</p>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Selected Plan:</span>
                  <p className="font-bold text-indigo-700">{submittedReceipt.plan}</p>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Timing Shift:</span>
                  <p className="font-bold text-slate-900">{submittedReceipt.preferredTiming}</p>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Preferred Start Date:</span>
                  <p className="font-bold text-slate-900">{submittedReceipt.startDate}</p>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Study Target / Exam:</span>
                  <p className="font-bold text-slate-900">{submittedReceipt.examPurpose || 'Self-Study'}</p>
                </div>
              </div>

              <div className="pt-3 text-xs text-slate-500">
                <span>Submitted on: {submittedReceipt.submittedAt}</span>
              </div>
            </div>

            {/* Quick Actions for Confirmation */}
            <div className="space-y-3">
              <p className="text-xs font-bold text-slate-700 uppercase tracking-wide text-center">
                Fast Track Your Seat Confirmation:
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <a
                  href={formatWhatsAppMessage(submittedReceipt)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white py-3 px-4 rounded-lg font-bold text-sm flex items-center justify-center space-x-2 transition-colors shadow-sm"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Send Details on WhatsApp</span>
                </a>

                <a
                  href={`tel:${LIBRARY_INFO.phone}`}
                  className="bg-indigo-700 hover:bg-indigo-800 text-white py-3 px-4 rounded-lg font-bold text-sm flex items-center justify-center space-x-2 transition-colors shadow-sm"
                >
                  <Phone className="w-4 h-4" />
                  <span>Call 9520200942 to Confirm</span>
                </a>
              </div>

              <div className="flex flex-wrap justify-center gap-3 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="text-xs text-slate-600 hover:text-slate-900 font-semibold px-3 py-1.5 border border-slate-300 rounded flex items-center bg-white"
                >
                  <Printer className="w-3.5 h-3.5 mr-1" />
                  <span>Print Receipt Slip</span>
                </button>
                <button
                  type="button"
                  onClick={handleReset}
                  className="text-xs text-indigo-700 hover:text-indigo-900 font-semibold px-3 py-1.5 rounded flex items-center"
                >
                  <RotateCcw className="w-3.5 h-3.5 mr-1" />
                  <span>Fill Another Form</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Form Content with All 12 Fields */
          <form 
            onSubmit={handleSubmit}
            id="library-registration-form"
            className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6"
            noValidate
          >
            {/* Field 1: Full Name */}
            <div>
              <label htmlFor="fullName" className="block text-sm font-bold text-slate-900 mb-1.5">
                1. Full Name <span className="text-rose-600">*</span>
              </label>
              <input
                type="text"
                id="fullName"
                name="fullName"
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                placeholder="Enter your full name"
                className={`w-full px-4 py-2.5 rounded-lg border text-sm transition-colors focus:outline-hidden focus:ring-2 focus:ring-indigo-600 ${
                  errors.fullName ? 'border-rose-400 bg-rose-50/40' : 'border-slate-300 bg-white'
                }`}
              />
              {errors.fullName && (
                <p className="text-rose-600 text-xs mt-1 flex items-center">
                  <AlertCircle className="w-3 h-3 mr-1" />
                  {errors.fullName}
                </p>
              )}
            </div>

            {/* Field 2 & 3: Mobile & Email */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label htmlFor="mobile" className="block text-sm font-bold text-slate-900 mb-1.5">
                  2. Mobile Number <span className="text-rose-600">*</span>
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 text-xs font-semibold">
                    +91
                  </span>
                  <input
                    type="tel"
                    id="mobile"
                    name="mobile"
                    maxLength={10}
                    value={formData.mobile}
                    onChange={(e) => setFormData({ ...formData, mobile: e.target.value.replace(/\D/g, '') })}
                    placeholder="10-digit mobile number"
                    className={`w-full pl-12 pr-4 py-2.5 rounded-lg border text-sm transition-colors focus:outline-hidden focus:ring-2 focus:ring-indigo-600 ${
                      errors.mobile ? 'border-rose-400 bg-rose-50/40' : 'border-slate-300 bg-white'
                    }`}
                  />
                </div>
                {errors.mobile && (
                  <p className="text-rose-600 text-xs mt-1 flex items-center">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    {errors.mobile}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-bold text-slate-900 mb-1.5">
                  3. Email Address <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="name@example.com"
                  className={`w-full px-4 py-2.5 rounded-lg border text-sm transition-colors focus:outline-hidden focus:ring-2 focus:ring-indigo-600 ${
                    errors.email ? 'border-rose-400 bg-rose-50/40' : 'border-slate-300 bg-white'
                  }`}
                />
                {errors.email && (
                  <p className="text-rose-600 text-xs mt-1 flex items-center">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    {errors.email}
                  </p>
                )}
              </div>
            </div>

            {/* Field 4 & 5: Date of Birth & Gender */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label htmlFor="dob" className="block text-sm font-bold text-slate-900 mb-1.5">
                  4. Date of Birth <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="date"
                  id="dob"
                  name="dob"
                  value={formData.dob}
                  onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 bg-white text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                />
              </div>

              <div>
                <label htmlFor="gender" className="block text-sm font-bold text-slate-900 mb-1.5">
                  5. Gender <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <select
                  id="gender"
                  name="gender"
                  value={formData.gender}
                  onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 bg-white text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                  <option value="Prefer not to say">Prefer not to say</option>
                </select>
              </div>
            </div>

            {/* Field 6 & 7: Occupation & Exam Purpose */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label htmlFor="occupation" className="block text-sm font-bold text-slate-900 mb-1.5">
                  6. Occupation <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <select
                  id="occupation"
                  name="occupation"
                  value={formData.occupation}
                  onChange={(e) => setFormData({ ...formData, occupation: e.target.value as any })}
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 bg-white text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                >
                  <option value="">Select Occupation</option>
                  <option value="Student">Student</option>
                  <option value="Working Professional">Working Professional</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label htmlFor="examPurpose" className="block text-sm font-bold text-slate-900 mb-1.5">
                  7. Exam / Study Purpose
                </label>
                <input
                  type="text"
                  id="examPurpose"
                  name="examPurpose"
                  value={formData.examPurpose}
                  onChange={(e) => setFormData({ ...formData, examPurpose: e.target.value })}
                  placeholder="e.g. SSC, UPSC, Banking, UP Police, NEET, College"
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 bg-white text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                />
              </div>
            </div>

            {/* Field 8: Membership Plan */}
            <div className="p-4 bg-indigo-50/50 rounded-xl border border-indigo-100">
              <label className="block text-sm font-bold text-slate-900 mb-2">
                8. Membership Plan <span className="text-rose-600">*</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label
                  htmlFor="plan-half-day"
                  className={`flex items-center p-3.5 rounded-lg border cursor-pointer transition-all ${
                    formData.plan === 'Half Day – ₹400'
                      ? 'border-indigo-600 bg-white shadow-xs ring-1 ring-indigo-600'
                      : 'border-slate-200 bg-white hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    id="plan-half-day"
                    name="plan"
                    value="Half Day – ₹400"
                    checked={formData.plan === 'Half Day – ₹400'}
                    onChange={(e) => setFormData({ ...formData, plan: e.target.value as any })}
                    className="w-4 h-4 text-indigo-600 focus:ring-indigo-500"
                  />
                  <div className="ml-3">
                    <span className="font-bold text-slate-900 text-sm block">Half Day – ₹400</span>
                    <span className="text-xs text-slate-500">8 Hours shift (Morning or Evening)</span>
                  </div>
                </label>

                <label
                  htmlFor="plan-full-day"
                  className={`flex items-center p-3.5 rounded-lg border cursor-pointer transition-all ${
                    formData.plan === 'Full Day – ₹600'
                      ? 'border-indigo-600 bg-white shadow-xs ring-1 ring-indigo-600'
                      : 'border-slate-200 bg-white hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    id="plan-full-day"
                    name="plan"
                    value="Full Day – ₹600"
                    checked={formData.plan === 'Full Day – ₹600'}
                    onChange={(e) => setFormData({ ...formData, plan: e.target.value as any })}
                    className="w-4 h-4 text-indigo-600 focus:ring-indigo-500"
                  />
                  <div className="ml-3">
                    <span className="font-bold text-slate-900 text-sm block">Full Day – ₹600</span>
                    <span className="text-xs text-slate-500">16 Hours full-day access (6 AM - 10 PM)</span>
                  </div>
                </label>
              </div>
              {errors.plan && (
                <p className="text-rose-600 text-xs mt-1.5">{errors.plan}</p>
              )}
            </div>

            {/* Field 9 & 10: Preferred Start Date & Preferred Timing */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label htmlFor="startDate" className="block text-sm font-bold text-slate-900 mb-1.5">
                  9. Preferred Start Date <span className="text-rose-600">*</span>
                </label>
                <input
                  type="date"
                  id="startDate"
                  name="startDate"
                  value={formData.startDate}
                  onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                  className={`w-full px-4 py-2.5 rounded-lg border text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-600 ${
                    errors.startDate ? 'border-rose-400 bg-rose-50/40' : 'border-slate-300 bg-white'
                  }`}
                />
                {errors.startDate && (
                  <p className="text-rose-600 text-xs mt-1">{errors.startDate}</p>
                )}
              </div>

              <div>
                <label htmlFor="preferredTiming" className="block text-sm font-bold text-slate-900 mb-1.5">
                  10. Preferred Timing <span className="text-rose-600">*</span>
                </label>
                <select
                  id="preferredTiming"
                  name="preferredTiming"
                  value={formData.preferredTiming}
                  onChange={(e) => setFormData({ ...formData, preferredTiming: e.target.value as any })}
                  className={`w-full px-4 py-2.5 rounded-lg border text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-600 ${
                    errors.preferredTiming ? 'border-rose-400 bg-rose-50/40' : 'border-slate-300 bg-white'
                  }`}
                >
                  <option value="">Select Shift Timing</option>
                  <option value="Morning">Morning (6:00 AM – 2:00 PM)</option>
                  <option value="Afternoon">Afternoon (11:00 AM – 6:00 PM)</option>
                  <option value="Evening">Evening (2:00 PM – 10:00 PM)</option>
                  <option value="Full Day">Full Day (6:00 AM – 10:00 PM)</option>
                </select>
                {errors.preferredTiming && (
                  <p className="text-rose-600 text-xs mt-1">{errors.preferredTiming}</p>
                )}
              </div>
            </div>

            {/* Field 11: How did you hear about us? */}
            <div>
              <label htmlFor="heardFrom" className="block text-sm font-bold text-slate-900 mb-1.5">
                11. How did you hear about us? <span className="text-slate-400 font-normal">(Optional)</span>
              </label>
              <select
                id="heardFrom"
                name="heardFrom"
                value={formData.heardFrom}
                onChange={(e) => setFormData({ ...formData, heardFrom: e.target.value as any })}
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 bg-white text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
              >
                <option value="">Select Option</option>
                <option value="Google">Google</option>
                <option value="Instagram">Instagram</option>
                <option value="WhatsApp">WhatsApp</option>
                <option value="Friend">Friend</option>
                <option value="Other">Other</option>
              </select>
            </div>

            {/* Field 12: Message/Requirement */}
            <div>
              <label htmlFor="message" className="block text-sm font-bold text-slate-900 mb-1.5">
                12. Message / Requirement <span className="text-slate-400 font-normal">(Optional)</span>
              </label>
              <textarea
                id="message"
                name="message"
                rows={3}
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="Any specific requirement? (e.g. corner desk, early morning batch, student discount query)"
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 bg-white text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
              />
            </div>

            {/* Privacy note */}
            <div className="text-xs text-slate-500 bg-slate-50 p-3 rounded-lg border border-slate-200">
              <span className="font-semibold text-slate-700">Privacy Notice:</span> Your information will only be used by Aadhay Library management to contact you regarding your seat availability and admission process.
            </div>

            {/* Submit Button */}
            <div>
              <button
                type="submit"
                id="submit-registration-btn"
                className="w-full bg-indigo-700 hover:bg-indigo-800 text-white py-3.5 px-6 rounded-lg font-bold text-base flex items-center justify-center space-x-2 transition-all shadow-md hover:shadow-lg active:scale-98"
              >
                <Send className="w-4 h-4" />
                <span>Submit Registration</span>
              </button>
            </div>
          </form>
        )}

        {/* Previous Submissions Modal */}
        {showHistoryModal && (
          <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl max-h-[85vh] overflow-y-auto">
              <div className="flex justify-between items-center pb-3 border-b border-slate-200 mb-4">
                <h3 className="font-bold text-slate-900 text-lg">Your Submitted Registrations</h3>
                <button
                  onClick={() => setShowHistoryModal(false)}
                  className="text-slate-400 hover:text-slate-700 text-sm font-bold"
                >
                  ✕ Close
                </button>
              </div>

              <div className="space-y-3">
                {savedSubmissions.map((sub) => (
                  <div key={sub.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50 text-xs">
                    <div className="flex justify-between font-bold text-slate-800 mb-1">
                      <span>{sub.id}</span>
                      <span className="text-indigo-700">{sub.plan}</span>
                    </div>
                    <p className="text-slate-600">Applicant: {sub.fullName} ({sub.mobile})</p>
                    <p className="text-slate-500">Timing: {sub.preferredTiming} | Starts: {sub.startDate}</p>
                    <div className="mt-2 pt-2 border-t border-slate-200 flex justify-between items-center">
                      <span className="text-[10px] text-slate-400">{sub.submittedAt}</span>
                      <a
                        href={formatWhatsAppMessage(sub)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-emerald-700 hover:text-emerald-800 font-bold"
                      >
                        Share via WhatsApp →
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
