import React from 'react';
import { X, ShieldCheck, FileCheck, CheckCircle2 } from 'lucide-react';
import { LIBRARY_INFO } from '../data/libraryData';

interface PolicyModalProps {
  type: 'privacy' | 'terms' | null;
  onClose: () => void;
}

export const PolicyModal: React.FC<PolicyModalProps> = ({ type, onClose }) => {
  if (!type) return null;

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center pb-4 border-b border-slate-200">
          <div className="flex items-center space-x-2">
            {type === 'privacy' ? (
              <ShieldCheck className="w-5 h-5 text-indigo-700" />
            ) : (
              <FileCheck className="w-5 h-5 text-indigo-700" />
            )}
            <h3 className="text-xl font-black text-slate-900">
              {type === 'privacy' ? 'Privacy Policy' : 'Terms & Conditions (Library Rules)'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-md hover:bg-slate-100 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {type === 'privacy' ? (
          <div className="py-6 space-y-4 text-sm text-slate-600 leading-relaxed">
            <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-xl text-indigo-950">
              <p className="font-semibold mb-1">Our Privacy Commitment</p>
              <p className="text-xs sm:text-sm">
                We respect the privacy of our visitors and members. Information submitted through our registration form may be used to process membership enquiries, confirm availability and contact applicants regarding library services. We do not intentionally sell personal information to third parties.
              </p>
            </div>

            <h4 className="font-bold text-slate-900 text-base mt-4">1. Information Collection</h4>
            <p>
              When registering at Aadhay Library, we collect basic contact information including your Full Name, Mobile Number, Email Address, Exam Purpose, and timing preferences. This information is purely used for seat allocation, admission verification, and communication regarding library access.
            </p>

            <h4 className="font-bold text-slate-900 text-base">2. Purpose of Processing</h4>
            <ul className="list-disc pl-5 space-y-1 text-xs sm:text-sm">
              <li>To evaluate seat availability in morning, evening, or full-day batches.</li>
              <li>To communicate payment verification and membership renewals.</li>
              <li>To notify students of emergency schedule changes or holiday notices.</li>
            </ul>

            <h4 className="font-bold text-slate-900 text-base">3. Data Security & Contact</h4>
            <p>
              Your contact details are kept secure and are strictly accessed by authorized library staff. For queries regarding your information, contact us at <a href={`mailto:${LIBRARY_INFO.email}`} className="text-indigo-700 font-bold underline">{LIBRARY_INFO.email}</a> or call <strong>{LIBRARY_INFO.phoneFormatted}</strong>.
            </p>
          </div>
        ) : (
          <div className="py-6 space-y-4 text-sm text-slate-600 leading-relaxed">
            <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl text-amber-950 text-xs sm:text-sm">
              <p className="font-bold mb-1">Important Code of Conduct</p>
              <p>
                All students and aspirants are requested to adhere strictly to the following library rules to maintain a disciplined and high-focus atmosphere.
              </p>
            </div>

            <div className="space-y-3">
              {[
                'Membership is subject to library rules and regulations at all times.',
                'Seat availability confirmation ke baad hi final membership confirm hogi.',
                'Strict silence is mandatory throughout the study hall. Mobile phones must be kept on silent mode; calls must only be taken outside the study premises.',
                'Do not damage or deface library property, desks, power points, or AC equipment. Members will be held liable for any deliberate damage.',
                'Membership transfer and refund policies will be strictly governed by Aadhay Library management guidelines.',
                'Food and beverages (except water bottles) are not permitted inside the quiet study hall. Designated refreshment spaces must be used.',
                'Any special discount or scholarship concession will be subject to applicable terms and verification of student identity.',
              ].map((rule, idx) => (
                <div key={idx} className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-indigo-700 shrink-0 mt-0.5" />
                  <span className="text-slate-800 text-xs sm:text-sm font-medium">{rule}</span>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-4 border-t border-slate-200 text-xs text-slate-500">
              By registering or visiting Aadhay Library, members agree to comply with all safety and study rules enforced by library management.
            </div>
          </div>
        )}

        <div className="pt-4 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs sm:text-sm px-5 py-2.5 rounded-lg transition-colors"
          >
            I Understand & Close
          </button>
        </div>
      </div>
    </div>
  );
};
