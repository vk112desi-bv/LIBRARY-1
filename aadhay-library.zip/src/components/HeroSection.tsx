import React from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  Phone, 
  CheckCircle2, 
  ShieldCheck, 
  Clock, 
  FileText, 
  BadgePercent,
  MapPin
} from 'lucide-react';
import { LIBRARY_INFO } from '../data/libraryData';
import { PageSection } from '../types';
import studyHallImg from '../assets/images/library_study_hall_1788633213780.jpg';

interface HeroSectionProps {
  onNavigate: (section: PageSection) => void;
  onOpenRegister: (plan?: 'Half Day – ₹400' | 'Full Day – ₹600') => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onNavigate,
  onOpenRegister,
}) => {
  return (
    <section className="relative overflow-hidden bg-white border-b border-slate-200">
      {/* Subtle background grid pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#f1f5f9_1px,transparent_1px),linear-gradient(to_bottom,#f1f5f9_1px,transparent_1px)] bg-[size:32px_32px] opacity-70 pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-12 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Hero Column */}
          <div className="lg:col-span-7">
            {/* Tagline Badge */}
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 bg-indigo-50 border border-indigo-100 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-widest mb-5 shadow-2xs">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>{LIBRARY_INFO.motto}</span>
              <span className="w-1 h-1 rounded-full bg-indigo-400"></span>
              <span>MEERUT</span>
            </div>

            {/* Main Headings */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-[1.15] mb-3">
              Welcome to{' '}
              <span className="text-indigo-700 block sm:inline">
                {LIBRARY_INFO.name}
              </span>
            </h1>

            <h2 className="text-xl sm:text-2xl font-bold text-slate-700 tracking-tight mb-4">
              Your Comfortable Self-Study Space in Meerut
            </h2>

            {/* Description */}
            <p className="text-base sm:text-lg text-slate-600 mb-8 leading-relaxed max-w-2xl">
              A peaceful and comfortable study environment designed for students and competitive-exam aspirants. 
              Enjoy a focused study space with AC, drinking water and comfortable seating.
            </p>

            {/* 4 Action Buttons as requested */}
            <div className="flex flex-wrap gap-3 sm:gap-4 mb-8">
              <button
                onClick={() => onOpenRegister()}
                id="hero-btn-register"
                className="bg-indigo-700 hover:bg-indigo-800 text-white px-6 sm:px-7 py-3 rounded-lg font-bold text-sm sm:text-base flex items-center transition-all shadow-md hover:shadow-lg transform active:scale-98"
              >
                <FileText className="w-4 h-4 mr-2" />
                <span>📝 Register Now</span>
              </button>

              <button
                onClick={() => onNavigate('fees')}
                id="hero-btn-fees"
                className="bg-white border-2 border-slate-300 hover:border-indigo-600 text-slate-800 hover:text-indigo-700 px-5 sm:px-6 py-3 rounded-lg font-bold text-sm sm:text-base transition-colors"
              >
                <span>💰 View Fees</span>
              </button>

              <button
                onClick={() => onNavigate('offers')}
                id="hero-btn-offers"
                className="bg-amber-50 border border-amber-200 hover:bg-amber-100 text-amber-900 px-4 sm:px-5 py-3 rounded-lg font-semibold text-sm sm:text-base transition-colors"
              >
                <span>🎁 Offers & Discounts</span>
              </button>

              <button
                onClick={() => onNavigate('contact')}
                id="hero-btn-contact"
                className="bg-slate-100 hover:bg-slate-200 text-slate-800 px-4 sm:px-5 py-3 rounded-lg font-semibold text-sm sm:text-base transition-colors"
              >
                <span>📞 Contact Us</span>
              </button>
            </div>

            {/* Trust points list */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-6 border-t border-slate-200 text-xs sm:text-sm text-slate-600 font-medium">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Fully Air Conditioned</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>RO Purified Drinking Water</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Clean & Silent Atmosphere</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Starting just ₹400/month</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Personal Power Sockets</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Open 7 Days (6 AM - 10 PM)</span>
              </div>
            </div>
          </div>

          {/* Right Visual Image & Quick Card */}
          <div className="lg:col-span-5">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Image Frame with Professional Polish styling */}
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 shadow-xl bg-slate-100 aspect-4/3 group">
                <img
                  src={studyHallImg}
                  alt="Aadhay Library Self-Study Hall in Meerut"
                  className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                />
                
                {/* Floating overlay chip */}
                <div className="absolute top-3 left-3 bg-slate-900/85 backdrop-blur-xs text-white px-3 py-1.5 rounded-md text-xs font-semibold flex items-center space-x-1.5 shadow-sm">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>Seats Available for Admission</span>
                </div>

                {/* Bottom glass banner */}
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-slate-950/90 via-slate-900/60 to-transparent p-5 text-white">
                  <p className="text-sm font-bold tracking-wide">
                    Aadhay Library • Self-Study Zone
                  </p>
                  <p className="text-xs text-slate-300 mt-0.5 flex items-center">
                    <MapPin className="w-3.5 h-3.5 mr-1 text-indigo-400" />
                    Meerut, Uttar Pradesh
                  </p>
                </div>
              </div>

              {/* Highlight Badge Card */}
              <div className="mt-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
                    Direct Admission Support
                  </span>
                  <a 
                    href={`tel:${LIBRARY_INFO.phone}`} 
                    className="text-base sm:text-lg font-extrabold text-indigo-700 hover:text-indigo-800 flex items-center mt-0.5"
                  >
                    <Phone className="w-4 h-4 mr-1.5 text-indigo-600" />
                    <span>{LIBRARY_INFO.phoneFormatted}</span>
                  </a>
                </div>
                <button
                  onClick={() => onOpenRegister()}
                  className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-3.5 py-2 rounded-md shadow-xs"
                >
                  Book Seat Now →
                </button>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
