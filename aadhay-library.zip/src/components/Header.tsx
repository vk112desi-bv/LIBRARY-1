import React, { useState } from 'react';
import { BookOpen, Phone, MessageCircle, Menu, X, Clock, MapPin } from 'lucide-react';
import { LIBRARY_INFO } from '../data/libraryData';
import { PageSection } from '../types';

interface HeaderProps {
  activeSection: PageSection;
  onNavigate: (section: PageSection) => void;
  onOpenRegister: (plan?: 'Half Day – ₹400' | 'Full Day – ₹600') => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeSection,
  onNavigate,
  onOpenRegister,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { id: PageSection; label: string }[] = [
    { id: 'home', label: 'HOME' },
    { id: 'fees', label: 'FEES' },
    { id: 'facilities', label: 'FACILITIES' },
    { id: 'register', label: 'REGISTER' },
    { id: 'gallery', label: 'GALLERY' },
    { id: 'location', label: 'LOCATION' },
    { id: 'contact', label: 'CONTACT' },
  ];

  const handleNavClick = (sectionId: PageSection) => {
    onNavigate(sectionId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs transition-all">
      {/* Top micro announcement bar */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 sm:px-8 flex flex-wrap justify-between items-center">
        <div className="flex items-center space-x-4">
          <span className="inline-flex items-center text-emerald-400 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-400 mr-1.5 animate-pulse"></span>
            Open Mon - Sun: 6:00 AM – 10:00 PM
          </span>
          <span className="hidden md:inline-flex items-center text-slate-300">
            <MapPin className="w-3.5 h-3.5 mr-1 text-indigo-400" />
            Meerut, Uttar Pradesh
          </span>
        </div>
        <div className="flex items-center space-x-4 text-xs">
          <a
            href={`tel:${LIBRARY_INFO.phone}`}
            id="top-bar-call-link"
            className="hover:text-white flex items-center transition-colors"
          >
            <Phone className="w-3 h-3 mr-1 text-indigo-400" />
            <span>9520200942</span>
          </a>
          <a
            href={LIBRARY_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            id="top-bar-whatsapp-link"
            className="hover:text-emerald-400 flex items-center text-emerald-300 transition-colors"
          >
            <MessageCircle className="w-3 h-3 mr-1" />
            <span>WhatsApp</span>
          </a>
        </div>
      </div>

      {/* Main navigation container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-3.5 flex justify-between items-center">
        {/* Brand identity */}
        <button
          onClick={() => handleNavClick('home')}
          id="brand-logo-button"
          className="flex items-center space-x-3 text-left focus:outline-hidden group"
        >
          <div className="w-10 h-10 bg-indigo-700 rounded-lg flex items-center justify-center text-white shadow-sm group-hover:bg-indigo-800 transition-colors">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 block leading-tight">
              {LIBRARY_INFO.name}
            </span>
            <span className="text-[11px] font-semibold text-indigo-700 tracking-wider uppercase block">
              {LIBRARY_INFO.motto}
            </span>
          </div>
        </button>

        {/* Desktop Menu navigation */}
        <nav className="hidden lg:flex items-center space-x-6 text-sm font-semibold tracking-wider text-slate-600">
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                id={`nav-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`py-1 transition-all cursor-pointer ${
                  isActive
                    ? 'text-indigo-700 border-b-2 border-indigo-700 font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:border-b-2 hover:border-slate-300'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Action button */}
        <div className="hidden sm:flex items-center space-x-3">
          <a
            href={`tel:${LIBRARY_INFO.phone}`}
            id="header-call-btn"
            className="border border-slate-300 text-slate-700 hover:bg-slate-50 px-3.5 py-2 rounded-md font-semibold text-sm flex items-center transition-colors"
          >
            <Phone className="w-4 h-4 mr-1.5 text-indigo-600" />
            <span>9520200942</span>
          </a>
          <button
            onClick={() => onOpenRegister()}
            id="header-register-now-btn"
            className="bg-indigo-700 text-white px-5 py-2 rounded-md font-bold text-sm hover:bg-indigo-800 transition-colors shadow-sm tracking-wide"
          >
            REGISTER NOW
          </button>
        </div>

        {/* Mobile menu hamburger toggle */}
        <div className="flex sm:hidden items-center space-x-2">
          <button
            onClick={() => onOpenRegister()}
            id="mobile-header-quick-reg-btn"
            className="bg-indigo-700 text-white px-3 py-1.5 rounded text-xs font-bold"
          >
            Register
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            id="mobile-menu-toggle-btn"
            className="p-2 text-slate-700 hover:text-indigo-700 focus:outline-hidden"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile dropdown drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-6 py-4 shadow-lg animate-fadeIn">
          <nav className="flex flex-col space-y-3">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  id={`mobile-nav-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`text-left text-sm py-2 px-3 rounded-md font-bold tracking-wide transition-colors ${
                    isActive
                      ? 'bg-indigo-50 text-indigo-700'
                      : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
            
            <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
              <button
                onClick={() => {
                  onNavigate('offers');
                  setMobileMenuOpen(false);
                }}
                className="text-left text-sm py-1.5 px-3 text-slate-600 hover:text-slate-900"
              >
                🎁 Special Offers & Discounts
              </button>
              <button
                onClick={() => {
                  onNavigate('timings');
                  setMobileMenuOpen(false);
                }}
                className="text-left text-sm py-1.5 px-3 text-slate-600 hover:text-slate-900"
              >
                🕐 Library Timings (6 AM – 10 PM)
              </button>
              <button
                onClick={() => {
                  onNavigate('about');
                  setMobileMenuOpen(false);
                }}
                className="text-left text-sm py-1.5 px-3 text-slate-600 hover:text-slate-900"
              >
                ℹ️ About Aadhay Library
              </button>
              <button
                onClick={() => {
                  onNavigate('faq');
                  setMobileMenuOpen(false);
                }}
                className="text-left text-sm py-1.5 px-3 text-slate-600 hover:text-slate-900"
              >
                ❓ Frequently Asked Questions
              </button>
            </div>

            <div className="pt-3 border-t border-slate-200 flex flex-col space-y-2">
              <a
                href={`tel:${LIBRARY_INFO.phone}`}
                className="w-full bg-slate-100 text-slate-800 text-center py-2.5 rounded-md font-bold text-sm flex items-center justify-center space-x-2"
              >
                <Phone className="w-4 h-4 text-indigo-700" />
                <span>Call 9520200942</span>
              </a>
              <button
                onClick={() => {
                  onOpenRegister();
                  setMobileMenuOpen(false);
                }}
                className="w-full bg-indigo-700 text-white text-center py-2.5 rounded-md font-bold text-sm shadow-sm"
              >
                📝 Register Online Now
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
