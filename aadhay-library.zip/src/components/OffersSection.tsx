import React from 'react';
import { 
  GraduationCap, 
  Users, 
  CalendarCheck, 
  Flame, 
  ArrowRight, 
  MessageCircle, 
  CheckCircle,
  Sparkles
} from 'lucide-react';
import { OFFERS, LIBRARY_INFO } from '../data/libraryData';

interface OffersSectionProps {
  onOpenRegister: () => void;
}

export const OffersSection: React.FC<OffersSectionProps> = ({ onOpenRegister }) => {
  const iconMap: Record<string, React.ElementType> = {
    GraduationCap,
    Users,
    CalendarCheck,
    Flame,
  };

  return (
    <section id="offers-section" className="py-12 lg:py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center space-x-1 px-3 py-1 bg-amber-50 text-amber-800 rounded-full text-xs font-bold uppercase tracking-widest mb-3 border border-amber-200">
            <Sparkles className="w-3.5 h-3.5 text-amber-600 mr-1" />
            <span>GENUINE & TRANSPARENT BENEFITS</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight">
            Special Discounts & Membership Offers
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Real, verifiable student benefits to support your competitive examination journey in Meerut.
          </p>
        </div>

        {/* 4 Offers Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {OFFERS.map((offer) => {
            const Icon = iconMap[offer.iconName] || Sparkles;
            return (
              <div
                key={offer.id}
                id={`offer-card-${offer.id}`}
                className="bg-white rounded-xl p-6 border border-slate-200 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center border border-indigo-100">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="bg-amber-100 text-amber-900 text-[11px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                      {offer.discountBadge}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 mb-2">
                    {offer.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-600 mb-4 leading-relaxed">
                    {offer.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div className="text-[11px] text-slate-500 font-medium flex items-center">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600 mr-1 shrink-0" />
                    <span>{offer.eligibility}</span>
                  </div>
                  <a
                    href={`https://wa.me/91${LIBRARY_INFO.phone}?text=Hello%20Aadhay%20Library%2C%20I%20would%20like%20to%20inquire%20about%20the%20${encodeURIComponent(offer.title)}.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-indigo-700 hover:text-indigo-900 font-bold flex items-center shrink-0 ml-2"
                  >
                    <span>Inquire</span>
                    <ArrowRight className="w-3 h-3 ml-1" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Note on Genuine Offers */}
        <div className="mt-10 max-w-2xl mx-auto text-center bg-white p-4 rounded-xl border border-slate-200 text-xs text-slate-600">
          <p className="font-semibold text-slate-800 mb-1">
            ⚠️ Transparent Pricing Policy
          </p>
          <p>
            At Aadhay Library, we publish only genuine, verified concessions. No inflated fake prices or false timers. 
            All discounts are applied directly during offline seat verification.
          </p>
        </div>

      </div>
    </section>
  );
};
