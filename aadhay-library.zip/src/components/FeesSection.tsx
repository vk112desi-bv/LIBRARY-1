import React from 'react';
import { Check, ArrowRight, ShieldCheck, Zap, HelpCircle } from 'lucide-react';
import { PLANS, LIBRARY_INFO } from '../data/libraryData';

interface FeesSectionProps {
  onOpenRegister: (plan?: 'Half Day – ₹400' | 'Full Day – ₹600') => void;
}

export const FeesSection: React.FC<FeesSectionProps> = ({ onOpenRegister }) => {
  return (
    <section id="fees-section" className="py-12 lg:py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-block px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-widest mb-3 border border-indigo-100">
            TRANSPARENT & AFFORDABLE PRICING
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight">
            Fees Structure & Study Plans
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Choose the membership plan that best fits your study routine in Meerut. No hidden fees.
          </p>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {PLANS.map((plan) => {
            const isFullDay = plan.id === 'full-day';
            const planSelectValue = isFullDay ? ('Full Day – ₹600' as const) : ('Half Day – ₹400' as const);

            return (
              <div
                key={plan.id}
                id={`pricing-card-${plan.id}`}
                className={`relative rounded-2xl p-6 sm:p-8 flex flex-col transition-all duration-300 ${
                  isFullDay
                    ? 'bg-slate-900 text-white shadow-xl ring-2 ring-indigo-600'
                    : 'bg-white text-slate-900 border border-slate-200 shadow-md hover:border-slate-300'
                }`}
              >
                {/* Badge if available */}
                {plan.badge && (
                  <div className="absolute -top-3 left-6 sm:left-8">
                    <span
                      className={`inline-block px-3 py-1 rounded-full text-xs font-black tracking-wide uppercase shadow-sm ${
                        isFullDay
                          ? 'bg-indigo-600 text-white'
                          : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                      }`}
                    >
                      {plan.badge}
                    </span>
                  </div>
                )}

                {/* Plan Title & Timing */}
                <div className="mb-5 mt-1">
                  <h3 className={`text-2xl font-black ${isFullDay ? 'text-white' : 'text-slate-900'}`}>
                    {plan.name}
                  </h3>
                  <p className={`text-xs mt-1 ${isFullDay ? 'text-slate-300' : 'text-slate-500'}`}>
                    {plan.timing}
                  </p>
                </div>

                {/* Price Display */}
                <div className="flex items-baseline mb-6 pb-6 border-b border-slate-200/20">
                  <span className="text-4xl sm:text-5xl font-black tracking-tight">
                    ₹{plan.fee}
                  </span>
                  <span className={`ml-2 text-sm font-semibold ${isFullDay ? 'text-slate-400' : 'text-slate-500'}`}>
                    / {plan.duration}
                  </span>
                </div>

                {/* Features List */}
                <div className="space-y-3.5 mb-8 flex-1">
                  <p className={`text-xs font-bold uppercase tracking-wider ${isFullDay ? 'text-indigo-400' : 'text-indigo-700'}`}>
                    Included with {plan.name}:
                  </p>
                  {plan.features.map((feature, idx) => (
                    <div key={idx} className="flex items-start space-x-3 text-xs sm:text-sm">
                      <div className={`p-0.5 rounded-full mt-0.5 shrink-0 ${isFullDay ? 'bg-indigo-500/20 text-indigo-400' : 'bg-emerald-50 text-emerald-600'}`}>
                        <Check className="w-4 h-4" />
                      </div>
                      <span className={isFullDay ? 'text-slate-200' : 'text-slate-700'}>
                        {feature}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Action CTA Button */}
                <button
                  onClick={() => onOpenRegister(planSelectValue)}
                  id={`register-plan-btn-${plan.id}`}
                  className={`w-full py-3.5 px-6 rounded-lg font-bold text-sm tracking-wide flex items-center justify-center space-x-2 transition-all shadow-md ${
                    isFullDay
                      ? 'bg-indigo-600 hover:bg-indigo-700 text-white hover:shadow-indigo-500/25'
                      : 'bg-indigo-700 hover:bg-indigo-800 text-white'
                  }`}
                >
                  <span>Select {plan.name} (₹{plan.fee})</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Quick Comparison Summary Table for clear glance */}
        <div className="mt-12 max-w-4xl mx-auto bg-slate-50 rounded-xl p-5 sm:p-6 border border-slate-200">
          <h4 className="font-bold text-slate-800 text-sm sm:text-base mb-3 flex items-center">
            <ShieldCheck className="w-4 h-4 mr-2 text-indigo-600" />
            Plan Comparison & Transparent Terms
          </h4>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 uppercase text-[11px] font-bold">
                  <th className="py-2.5 px-3">Plan Name</th>
                  <th className="py-2.5 px-3">Monthly Fee</th>
                  <th className="py-2.5 px-3">Daily Access Duration</th>
                  <th className="py-2.5 px-3">Facilities Included</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-700">
                <tr>
                  <td className="py-3 px-3 font-bold text-slate-900">Half Day</td>
                  <td className="py-3 px-3 font-extrabold text-indigo-700">₹400 / month</td>
                  <td className="py-3 px-3">8 Hours (Morning or Evening)</td>
                  <td className="py-3 px-3">Comfortable study seat, AC, RO water, silence</td>
                  <td className="py-3 px-3 text-right">
                    <button
                      onClick={() => onOpenRegister('Half Day – ₹400')}
                      className="text-xs bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold px-3 py-1.5 rounded transition-colors"
                    >
                      Book ₹400
                    </button>
                  </td>
                </tr>
                <tr>
                  <td className="py-3 px-3 font-bold text-slate-900">Full Day</td>
                  <td className="py-3 px-3 font-extrabold text-indigo-700">₹600 / month</td>
                  <td className="py-3 px-3">16 Hours (6:00 AM – 10:00 PM)</td>
                  <td className="py-3 px-3">Dedicated seat, AC, RO water, full-day access, WiFi</td>
                  <td className="py-3 px-3 text-right">
                    <button
                      onClick={() => onOpenRegister('Full Day – ₹600')}
                      className="text-xs bg-indigo-700 hover:bg-indigo-800 text-white font-bold px-3 py-1.5 rounded transition-colors"
                    >
                      Book ₹600
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          
          {/* Note from prompt */}
          <div className="mt-4 pt-3 border-t border-slate-200 text-xs text-slate-500 flex items-start space-x-2">
            <HelpCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <p>
              <strong>Note on Membership Fees:</strong> Rates are listed as monthly (per month) membership fees. 
              Seat confirmation is provided on a first-come, first-served basis. Fees can be paid via UPI, Cash, or Bank Transfer upon seat inspection.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
