import React, { useState, useEffect } from 'react';
import { Clock, Sun, Moon, Calendar, CheckCircle2, Sparkles } from 'lucide-react';
import { TIMING_SCHEDULE, LIBRARY_INFO } from '../data/libraryData';

export const TimingsSection: React.FC = () => {
  const [isOpenNow, setIsOpenNow] = useState(true);

  useEffect(() => {
    // Check IST time
    const now = new Date();
    // Convert to Indian Standard Time (UTC+5:30)
    const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
    const istDate = new Date(utc + (3600000 * 5.5));
    const hours = istDate.getHours();
    // Open from 6:00 AM (hour 6) to 10:00 PM (hour 22)
    setIsOpenNow(hours >= 6 && hours < 22);
  }, []);

  return (
    <section id="timings-section" className="py-12 lg:py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-widest mb-3 border border-indigo-100">
            <Clock className="w-3.5 h-3.5 mr-1" />
            <span>OPEN 7 DAYS A WEEK</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight">
            Library Timings & Shifts
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Flexible morning, evening, and full-day study hours designed around competitive aspirants' routines.
          </p>
        </div>

        {/* Live Status Banner */}
        <div className="max-w-3xl mx-auto mb-10 bg-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-md flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold ${
              isOpenNow ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400'
            }`}>
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className={`w-2.5 h-2.5 rounded-full ${isOpenNow ? 'bg-emerald-400 animate-pulse' : 'bg-rose-400'}`}></span>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Current Status
                </span>
              </div>
              <p className="text-lg sm:text-xl font-black text-white mt-0.5">
                {isOpenNow ? 'Library is Currently OPEN' : 'Library is Currently CLOSED (Opens at 6:00 AM)'}
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-slate-400 block font-semibold">Weekly Schedule</span>
            <span className="text-sm sm:text-base font-extrabold text-indigo-300">
              Monday – Sunday (All 7 Days)
            </span>
          </div>
        </div>

        {/* Shift Breakdown Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {TIMING_SCHEDULE.map((shift, idx) => {
            const isFullDay = idx === 2;
            return (
              <div
                key={idx}
                id={`timing-card-${idx}`}
                className={`rounded-2xl p-6 border flex flex-col justify-between transition-all ${
                  isFullDay
                    ? 'bg-indigo-50/70 border-indigo-200 shadow-sm'
                    : 'bg-white border-slate-200 shadow-xs hover:border-slate-300'
                }`}
              >
                <div>
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 bg-white px-2.5 py-1 rounded-full border border-indigo-100">
                      {shift.badge}
                    </span>
                    <span className="text-xs font-bold text-slate-500">{shift.duration}</span>
                  </div>

                  <h3 className="text-xl font-black text-slate-900 mb-1">
                    {shift.title}
                  </h3>

                  <div className="text-lg font-extrabold text-indigo-700 font-mono my-2">
                    {shift.time}
                  </div>

                  <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                    {shift.description}
                  </p>
                </div>

                <div className="pt-4 mt-6 border-t border-slate-200/60 text-xs text-slate-500 flex items-center">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mr-1.5 shrink-0" />
                  <span>Fully AC & quiet environment guaranteed</span>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
