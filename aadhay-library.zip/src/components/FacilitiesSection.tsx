import React from 'react';
import { 
  Snowflake, 
  Droplets, 
  Armchair, 
  Lightbulb, 
  Zap, 
  Wifi, 
  Car, 
  BookOpen, 
  VolumeX, 
  Sparkles 
} from 'lucide-react';
import { FACILITIES } from '../data/libraryData';

export const FacilitiesSection: React.FC = () => {
  const iconMap: Record<string, React.ElementType> = {
    Snowflake,
    Droplets,
    Armchair,
    Lightbulb,
    Zap,
    Wifi,
    Car,
    BookOpen,
    VolumeX,
    Sparkles,
  };

  return (
    <section id="facilities-section" className="py-12 lg:py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-widest mb-3 border border-indigo-100">
            <Sparkles className="w-3.5 h-3.5 mr-1" />
            <span>STUDY IN COMPLETE COMFORT</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight">
            Available Facilities
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Every facility at Aadhay Library is intentionally curated to support long, uninterrupted self-study hours.
          </p>
        </div>

        {/* 10 Facilities Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {FACILITIES.map((facility) => {
            const Icon = iconMap[facility.iconName] || Sparkles;
            return (
              <div
                key={facility.id}
                id={`facility-card-${facility.id}`}
                className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition-all flex items-start space-x-4 group"
              >
                <div className={`p-3 rounded-xl shrink-0 ${facility.color} group-hover:scale-105 transition-transform`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-bold text-slate-900 text-base group-hover:text-indigo-700 transition-colors">
                      {facility.title}
                    </h3>
                    {facility.badge && (
                      <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                        {facility.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    {facility.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
