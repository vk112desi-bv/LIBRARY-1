import React from 'react';
import { Phone, MessageCircle, FileText } from 'lucide-react';
import { LIBRARY_INFO } from '../data/libraryData';

interface FloatingBarProps {
  onOpenRegister: () => void;
}

export const FloatingBar: React.FC<FloatingBarProps> = ({ onOpenRegister }) => {
  return (
    <div className="fixed bottom-3 inset-x-3 sm:bottom-6 sm:right-6 sm:inset-x-auto z-40 flex items-center justify-between sm:justify-end gap-2 bg-slate-900/95 backdrop-blur-md p-2 rounded-2xl sm:rounded-full border border-slate-700 shadow-2xl">
      {/* Quick Call */}
      <a
        href={`tel:${LIBRARY_INFO.phone}`}
        id="floating-call-btn"
        className="flex-1 sm:flex-none flex items-center justify-center space-x-1.5 px-3 py-2 sm:py-2.5 rounded-xl sm:rounded-full bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-all"
        title="Call Library Management"
      >
        <Phone className="w-3.5 h-3.5 text-indigo-400" />
        <span className="hidden xs:inline">Call</span>
        <span className="sm:hidden text-[11px] font-mono">9520200942</span>
      </a>

      {/* WhatsApp */}
      <a
        href={LIBRARY_INFO.whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        id="floating-whatsapp-btn"
        className="flex-1 sm:flex-none flex items-center justify-center space-x-1.5 px-3 py-2 sm:py-2.5 rounded-xl sm:rounded-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs"
        title="Chat on WhatsApp"
      >
        <MessageCircle className="w-3.5 h-3.5" />
        <span>WhatsApp</span>
      </a>

      {/* Register */}
      <button
        onClick={onOpenRegister}
        id="floating-register-btn"
        className="flex-1 sm:flex-none flex items-center justify-center space-x-1.5 px-3.5 py-2 sm:py-2.5 rounded-xl sm:rounded-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-md"
      >
        <FileText className="w-3.5 h-3.5" />
        <span>Register Seat</span>
      </button>
    </div>
  );
};
