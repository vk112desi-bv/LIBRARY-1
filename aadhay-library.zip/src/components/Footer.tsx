import React from 'react';
import { BookOpen, Phone, Mail, MapPin, Heart, ArrowUp } from 'lucide-react';
import { LIBRARY_INFO } from '../data/libraryData';
import { PageSection } from '../types';

interface FooterProps {
  onNavigate: (section: PageSection) => void;
  onOpenPolicy: (type: 'privacy' | 'terms') => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenPolicy }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-900 text-white border-t border-slate-800">
      {/* Upper Footer Columns */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8">
          
          {/* Brand Col */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold">
                <BookOpen className="w-5 h-5" />
              </div>
              <span className="text-xl font-black tracking-tight text-white">
                {LIBRARY_INFO.name}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm">
              {LIBRARY_INFO.tagline}. Dedicated to helping competitive exam aspirants prepare in a peaceful, air-conditioned environment.
            </p>
            <div className="pt-2 text-xs text-slate-400">
              <p className="font-semibold text-slate-200">Study • Focus • Success</p>
              <p className="text-slate-500 mt-1">Open 7 Days a week: 6:00 AM – 10:00 PM</p>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-400">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-slate-300">
              <li>
                <button onClick={() => onNavigate('home')} className="hover:text-white transition-colors cursor-pointer">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('fees')} className="hover:text-white transition-colors cursor-pointer">
                  Fees Structure
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('facilities')} className="hover:text-white transition-colors cursor-pointer">
                  Facilities
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('register')} className="hover:text-white transition-colors cursor-pointer">
                  Online Registration
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('gallery')} className="hover:text-white transition-colors cursor-pointer">
                  Photo Gallery
                </button>
              </li>
            </ul>
          </div>

          {/* Information Pages */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-400">
              Information & Guidelines
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-slate-300">
              <li>
                <button onClick={() => onNavigate('location')} className="hover:text-white transition-colors cursor-pointer">
                  Location & Map
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('timings')} className="hover:text-white transition-colors cursor-pointer">
                  Library Timings (6 AM - 10 PM)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('offers')} className="hover:text-white transition-colors cursor-pointer">
                  Discounts & Special Offers
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-white transition-colors cursor-pointer">
                  About Aadhay Library
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('faq')} className="hover:text-white transition-colors cursor-pointer">
                  FAQ (Help & Answers)
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Direct */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-400">
              Contact & Support
            </h4>
            <div className="space-y-2.5 text-xs sm:text-sm text-slate-300">
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-indigo-400 shrink-0" />
                <a href={`tel:${LIBRARY_INFO.phone}`} className="hover:text-white font-bold">
                  {LIBRARY_INFO.phoneFormatted}
                </a>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-indigo-400 shrink-0" />
                <a href={`mailto:${LIBRARY_INFO.email}`} className="hover:text-white break-all">
                  {LIBRARY_INFO.email}
                </a>
              </div>
              <div className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                <span className="text-slate-400">
                  {LIBRARY_INFO.city}
                </span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => onNavigate('register')}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold py-2.5 px-4 rounded-md transition-colors shadow-sm"
              >
                Register For Seat Online
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* Lower Bar Matching Design Theme */}
      <div className="border-t border-slate-800 px-4 sm:px-8 py-5">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center text-xs text-slate-400 gap-4">
          <div className="flex flex-wrap items-center gap-4 sm:gap-6">
            <div className="flex items-center text-slate-300 font-medium">
              <Phone className="w-4 h-4 mr-1.5 text-indigo-400" />
              <span>{LIBRARY_INFO.phone}</span>
            </div>
            <div className="flex items-center text-slate-300 font-medium">
              <Mail className="w-4 h-4 mr-1.5 text-indigo-400" />
              <span>{LIBRARY_INFO.email}</span>
            </div>
          </div>

          <div className="flex items-center space-x-6 text-slate-400">
            <button
              onClick={() => onNavigate('faq')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              FAQ
            </button>
            <button
              onClick={() => onOpenPolicy('privacy')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Privacy Policy
            </button>
            <button
              onClick={() => onOpenPolicy('terms')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Terms of Service
            </button>
            <button
              onClick={scrollToTop}
              className="p-1 rounded bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors ml-2"
              title="Scroll to top"
            >
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
