import React from 'react';
import { MapPin, Navigation, Phone, MessageCircle, Clock } from 'lucide-react';
import { LIBRARY_INFO } from '../data/libraryData';

export const LocationSection: React.FC = () => {
  return (
    <section id="location-section" className="py-12 lg:py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center space-x-1 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-widest mb-3 border border-indigo-100">
            <MapPin className="w-3.5 h-3.5 mr-1" />
            <span>ACCESSIBLE & PRIME LOCATION</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight">
            Find Our Library
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Centrally located in Meerut with easy transit, parking space, and a peaceful study neighborhood.
          </p>
        </div>

        {/* Location Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Address & Contact Details Card */}
          <div className="lg:col-span-5 flex flex-col justify-between bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-indigo-50 text-indigo-700 rounded-xl flex items-center justify-center border border-indigo-100">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900">{LIBRARY_INFO.name}</h3>
                  <p className="text-xs text-slate-500">Meerut, Uttar Pradesh</p>
                </div>
              </div>

              {/* Address Details */}
              <div className="space-y-4 text-sm text-slate-700 mb-8">
                <div>
                  <span className="text-xs font-bold uppercase text-slate-400 block mb-1">
                    Physical Address:
                  </span>
                  <p className="font-semibold text-slate-900 leading-relaxed">
                    {LIBRARY_INFO.address}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Conveniently accessible from University campus, Delhi Road, and Civil Lines.
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100">
                  <span className="text-xs font-bold uppercase text-slate-400 block mb-1">
                    Operating Schedule:
                  </span>
                  <div className="flex items-center text-slate-900 font-semibold">
                    <Clock className="w-4 h-4 mr-2 text-indigo-600" />
                    <span>Monday – Sunday: 6:00 AM – 10:00 PM</span>
                  </div>
                  <p className="text-xs text-emerald-600 font-bold mt-1">
                    Open all 7 days for serious exam preparation
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100">
                  <span className="text-xs font-bold uppercase text-slate-400 block mb-1">
                    Contact for Assistance:
                  </span>
                  <p className="text-slate-900 font-bold text-base">
                    📞 {LIBRARY_INFO.phoneFormatted}
                  </p>
                  <p className="text-xs text-slate-500">
                    📧 {LIBRARY_INFO.email}
                  </p>
                </div>
              </div>
            </div>

            {/* Action Buttons as requested */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-4 border-t border-slate-100">
              <a
                href={LIBRARY_INFO.googleMapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                id="btn-get-directions"
                className="bg-indigo-700 hover:bg-indigo-800 text-white py-3 px-4 rounded-lg font-bold text-sm flex items-center justify-center space-x-2 transition-colors shadow-xs"
              >
                <Navigation className="w-4 h-4" />
                <span>📍 Get Directions</span>
              </a>

              <a
                href={`tel:${LIBRARY_INFO.phone}`}
                id="btn-call-location"
                className="border-2 border-slate-300 hover:border-indigo-600 text-slate-800 hover:text-indigo-700 py-3 px-4 rounded-lg font-bold text-sm flex items-center justify-center space-x-2 transition-colors"
              >
                <Phone className="w-4 h-4 text-indigo-600" />
                <span>📞 Call Now</span>
              </a>
            </div>
          </div>

          {/* Google Map Frame */}
          <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden min-h-[360px] flex flex-col">
            <div className="p-3 bg-slate-100 border-b border-slate-200 flex items-center justify-between text-xs text-slate-600">
              <div className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <span className="font-semibold">Interactive Google Map Location (Meerut)</span>
              </div>
              <a
                href={LIBRARY_INFO.googleMapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-indigo-700 font-bold hover:underline"
              >
                Open in Fullscreen Map ↗
              </a>
            </div>

            <div className="flex-1 relative w-full h-full min-h-[320px]">
              <iframe
                title="Aadhay Library Location Map"
                src={LIBRARY_INFO.mapEmbedUrl}
                className="w-full h-full border-0 absolute inset-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
