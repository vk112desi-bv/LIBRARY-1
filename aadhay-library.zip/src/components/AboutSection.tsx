import React from 'react';
import { 
  BookOpen, 
  Target, 
  Sparkles, 
  CheckCircle, 
  Phone, 
  Mail, 
  Award,
  Users
} from 'lucide-react';
import { LIBRARY_INFO } from '../data/libraryData';

export const AboutSection: React.FC = () => {
  return (
    <section id="about-section" className="py-12 lg:py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-widest mb-3 border border-indigo-100">
            <BookOpen className="w-3.5 h-3.5 mr-1" />
            <span>OUR MISSION & VISION</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight">
            About {LIBRARY_INFO.name}
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Built with a singular focus: providing Meerut students with a world-class, distraction-free environment to turn ambitions into success.
          </p>
        </div>

        {/* Story & Philosophy Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center max-w-5xl mx-auto">
          
          <div className="lg:col-span-7 space-y-4 text-slate-600 text-sm sm:text-base leading-relaxed">
            <p className="text-slate-900 font-semibold text-base sm:text-lg">
              {LIBRARY_INFO.name} is founded and managed by <span className="text-indigo-700 font-bold">{LIBRARY_INFO.ownerName}</span> as a premier, comfortable self-study space designed for students and competitive-exam aspirants in Meerut.
            </p>
            <p>
              Under the visionary leadership of Deepak Taliyan, we aim to provide a focused and comfortable study environment with essential facilities such as air conditioning, clean drinking water, and dedicated seating so you never have to battle noise, power cuts, or cramped spaces at home.
            </p>
            <p>
              Our goal is to provide students with a clean, peaceful and study-friendly environment where they can concentrate 100% on their preparation for UPSC, SSC CGL/CHSL, Banking (IBPS/SBI), Railways, UP Police, State PCS, NEET, JEE, and academic degrees.
            </p>

            {/* Owner & Founder Spotlight Badge */}
            <div className="p-4 bg-indigo-50/80 border border-indigo-100 rounded-xl flex items-center space-x-3.5">
              <div className="w-11 h-11 rounded-full bg-indigo-700 text-white flex items-center justify-center font-black text-sm shrink-0 shadow-xs">
                DT
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-indigo-700">Owner & Founder</span>
                  <span className="text-[11px] bg-white px-2 py-0.5 rounded text-slate-700 font-semibold border border-indigo-100">Management In-Charge</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 mt-0.5">{LIBRARY_INFO.ownerName}</h4>
                <p className="text-xs text-slate-600 mt-0.5">
                  Personally committed to maintaining strict discipline, silent study zones, and uninterrupted facilities.
                </p>
              </div>
            </div>

            {/* Core Facilities Checklist as requested */}
            <div className="pt-4 border-t border-slate-200 space-y-2.5">
              <h4 className="font-bold text-slate-900 text-sm uppercase tracking-wide">
                Key Facilities at Aadhay Library:
              </h4>
              {[
                'Fully AC study environment',
                'Comfortable seating with ergonomic chairs',
                'Drinking water (RO Purified)',
                'Peaceful study atmosphere with strict zero-noise policy',
                'Convenient online registration process',
              ].map((item, idx) => (
                <div key={idx} className="flex items-center space-x-2 text-sm text-slate-700">
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>

            {/* Direct contact footer */}
            <div className="pt-4 text-xs text-slate-500">
              For membership queries and seat availability:
              <div className="flex flex-wrap gap-4 mt-2 font-bold text-slate-800 text-sm">
                <a href={`tel:${LIBRARY_INFO.phone}`} className="flex items-center text-indigo-700 hover:underline">
                  <Phone className="w-4 h-4 mr-1.5" />
                  {LIBRARY_INFO.phoneFormatted}
                </a>
                <a href={`mailto:${LIBRARY_INFO.email}`} className="flex items-center text-indigo-700 hover:underline">
                  <Mail className="w-4 h-4 mr-1.5" />
                  {LIBRARY_INFO.email}
                </a>
              </div>
            </div>
          </div>

          {/* Right Highlights Card */}
          <div className="lg:col-span-5 bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-black text-xl">
                01
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-base">Study Without Distraction</h4>
                <p className="text-xs text-slate-500">Silent zone with zero conversation tolerance</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-black text-xl">
                02
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-base">Focus On Consistency</h4>
                <p className="text-xs text-slate-500">16 hours daily access from 6:00 AM to 10:00 PM</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-black text-xl">
                03
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-base">Student-First Pricing</h4>
                <p className="text-xs text-slate-500">Starting at ₹400 for Half Day & ₹600 for Full Day</p>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
