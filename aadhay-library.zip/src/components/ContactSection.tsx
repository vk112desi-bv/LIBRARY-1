import React, { useState } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  MessageCircle, 
  Navigation, 
  FileText, 
  Send, 
  CheckCircle2,
  Clock,
  UserCheck
} from 'lucide-react';
import { LIBRARY_INFO } from '../data/libraryData';

interface ContactSectionProps {
  onOpenRegister: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ onOpenRegister }) => {
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryPhone, setInquiryPhone] = useState('');
  const [inquiryMessage, setInquiryMessage] = useState('');
  const [inquirySent, setInquirySent] = useState(false);

  const handleQuickInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryName.trim() || !inquiryPhone.trim()) return;

    const text = `*NEW INQUIRY - AADHAY LIBRARY*
Name: ${inquiryName}
Phone: ${inquiryPhone}
Message: ${inquiryMessage || 'Inquiring about seat availability and admission.'}`;

    const waUrl = `https://wa.me/91${LIBRARY_INFO.phone}?text=${encodeURIComponent(text)}`;
    window.open(waUrl, '_blank');
    setInquirySent(true);
  };

  return (
    <section id="contact-section" className="py-12 lg:py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-widest mb-3 border border-indigo-100">
            <Phone className="w-3.5 h-3.5 mr-1" />
            <span>WE ARE HERE TO ASSIST YOU</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight">
            Contact {LIBRARY_INFO.name}
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Have questions about seat availability, fees, or visit timings? Connect with us directly.
          </p>
        </div>

        {/* 4 Quick Action Buttons as explicitly requested */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 max-w-4xl mx-auto mb-12">
          <a
            href={`tel:${LIBRARY_INFO.phone}`}
            id="quick-btn-call"
            className="bg-indigo-700 hover:bg-indigo-800 text-white p-4 rounded-xl font-bold text-sm sm:text-base flex flex-col items-center justify-center text-center space-y-1.5 shadow-xs transition-all active:scale-98"
          >
            <Phone className="w-5 h-5 text-indigo-200" />
            <span>Call Now</span>
            <span className="text-[11px] font-normal text-indigo-200">9520200942</span>
          </a>

          <a
            href={LIBRARY_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            id="quick-btn-whatsapp"
            className="bg-emerald-600 hover:bg-emerald-700 text-white p-4 rounded-xl font-bold text-sm sm:text-base flex flex-col items-center justify-center text-center space-y-1.5 shadow-xs transition-all active:scale-98"
          >
            <MessageCircle className="w-5 h-5 text-emerald-200" />
            <span>WhatsApp Us</span>
            <span className="text-[11px] font-normal text-emerald-200">Instant Chat</span>
          </a>

          <a
            href={LIBRARY_INFO.googleMapsDirectionsUrl}
            target="_blank"
            rel="noopener noreferrer"
            id="quick-btn-directions"
            className="bg-slate-800 hover:bg-slate-900 text-white p-4 rounded-xl font-bold text-sm sm:text-base flex flex-col items-center justify-center text-center space-y-1.5 shadow-xs transition-all active:scale-98"
          >
            <Navigation className="w-5 h-5 text-slate-300" />
            <span>Get Directions</span>
            <span className="text-[11px] font-normal text-slate-300">Meerut, UP</span>
          </a>

          <button
            onClick={onOpenRegister}
            id="quick-btn-register"
            className="bg-amber-600 hover:bg-amber-700 text-white p-4 rounded-xl font-bold text-sm sm:text-base flex flex-col items-center justify-center text-center space-y-1.5 shadow-xs transition-all active:scale-98"
          >
            <FileText className="w-5 h-5 text-amber-200" />
            <span>Register Now</span>
            <span className="text-[11px] font-normal text-amber-200">Online Form</span>
          </button>
        </div>

        {/* Detailed Contact Info & Quick Message Box */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 max-w-5xl mx-auto">
          
          {/* Contact Details Card */}
          <div className="lg:col-span-6 bg-slate-50 p-6 sm:p-8 rounded-2xl border border-slate-200 space-y-6">
            <h3 className="text-xl font-bold text-slate-900">Direct Contact Details</h3>

            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Phone & WhatsApp</span>
                <a href={`tel:${LIBRARY_INFO.phone}`} className="text-base font-bold text-slate-900 hover:text-indigo-700">
                  {LIBRARY_INFO.phoneFormatted}
                </a>
                <p className="text-xs text-slate-500 mt-0.5">Available for calls between 6:00 AM – 10:00 PM</p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Official Email</span>
                <a href={`mailto:${LIBRARY_INFO.email}`} className="text-base font-bold text-slate-900 hover:text-indigo-700">
                  {LIBRARY_INFO.email}
                </a>
                <p className="text-xs text-slate-500 mt-0.5">For queries, admissions and feedback</p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Library Location</span>
                <p className="text-sm font-semibold text-slate-900">
                  {LIBRARY_INFO.address}
                </p>
                <p className="text-xs text-slate-500 mt-0.5">Meerut, Uttar Pradesh - 250002</p>
              </div>
            </div>

            <div className="flex items-start space-x-4 pt-2 border-t border-slate-200">
              <div className="w-10 h-10 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Operating Hours</span>
                <p className="text-sm font-semibold text-slate-900">
                  Monday – Sunday: 6:00 AM – 10:00 PM
                </p>
                <p className="text-xs text-emerald-600 font-bold mt-0.5">Open 365 Days a Year</p>
              </div>
            </div>
          </div>

          {/* Quick Message Box */}
          <div className="lg:col-span-6 bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-xl font-bold text-slate-900 mb-2">Send a Quick Message</h3>
            <p className="text-xs sm:text-sm text-slate-600 mb-6">
              Leave your inquiry and we will get back to you immediately via WhatsApp or phone call.
            </p>

            {inquirySent ? (
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-6 text-center">
                <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
                <h4 className="font-bold text-slate-900">Inquiry Prepared!</h4>
                <p className="text-xs text-slate-600 mt-1">
                  Your WhatsApp message window has opened. Send it to directly chat with management.
                </p>
                <button
                  onClick={() => setInquirySent(false)}
                  className="mt-4 text-xs font-bold text-indigo-700 hover:underline"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleQuickInquiry} className="space-y-4">
                <div>
                  <label htmlFor="inquiryName" className="block text-xs font-bold text-slate-700 mb-1">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    id="inquiryName"
                    required
                    value={inquiryName}
                    onChange={(e) => setInquiryName(e.target.value)}
                    placeholder="e.g. Rahul Sharma"
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label htmlFor="inquiryPhone" className="block text-xs font-bold text-slate-700 mb-1">
                    Your Mobile Number *
                  </label>
                  <input
                    type="tel"
                    id="inquiryPhone"
                    required
                    maxLength={10}
                    value={inquiryPhone}
                    onChange={(e) => setInquiryPhone(e.target.value.replace(/\D/g, ''))}
                    placeholder="10-digit mobile number"
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <div>
                  <label htmlFor="inquiryMessage" className="block text-xs font-bold text-slate-700 mb-1">
                    Inquiry Message (Optional)
                  </label>
                  <textarea
                    id="inquiryMessage"
                    rows={3}
                    value={inquiryMessage}
                    onChange={(e) => setInquiryMessage(e.target.value)}
                    placeholder="Ask about seat availability, AC hall, or visit timing..."
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-600"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-4 rounded-lg text-sm flex items-center justify-center space-x-2 transition-colors shadow-xs"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Send via WhatsApp</span>
                </button>
              </form>
            )}
          </div>

        </div>

      </div>
    </section>
  );
};
