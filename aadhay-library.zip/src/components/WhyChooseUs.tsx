import React from 'react';
import { 
  Snowflake, 
  Droplets, 
  Armchair, 
  VolumeX, 
  BookOpen, 
  Smartphone,
  Sparkles
} from 'lucide-react';
import { PageSection } from '../types';

interface WhyChooseUsProps {
  onOpenRegister: () => void;
}

export const WhyChooseUs: React.FC<WhyChooseUsProps> = ({ onOpenRegister }) => {
  const cards = [
    {
      icon: Snowflake,
      title: 'Fully AC',
      description: 'Comfortable air-conditioned study environment.',
      iconBg: 'bg-indigo-50 text-indigo-700 border-indigo-100',
    },
    {
      icon: Droplets,
      title: 'Drinking Water',
      description: 'Clean drinking water facility available.',
      iconBg: 'bg-blue-50 text-blue-600 border-blue-100',
    },
    {
      icon: Armchair,
      title: 'Comfortable Seating',
      description: 'Dedicated seating for focused self-study.',
      iconBg: 'bg-emerald-50 text-emerald-700 border-emerald-100',
    },
    {
      icon: VolumeX,
      title: 'Peaceful Environment',
      description: 'Quiet atmosphere for better concentration.',
      iconBg: 'bg-amber-50 text-amber-700 border-amber-100',
    },
    {
      icon: BookOpen,
      title: 'Study Friendly',
      description: 'Suitable for students and competitive-exam preparation.',
      iconBg: 'bg-purple-50 text-purple-700 border-purple-100',
    },
    {
      icon: Smartphone,
      title: 'Easy Registration',
      description: 'Register online before visiting the library.',
      iconBg: 'bg-rose-50 text-rose-700 border-rose-100',
    },
  ];

  return (
    <section className="py-12 lg:py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-12">
          <div className="inline-flex items-center space-x-1 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-widest mb-3 border border-indigo-100">
            <Sparkles className="w-3 h-3 mr-1" />
            <span>EXCELLENCE IN EVERY DETAIL</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight">
            Why Choose Us?
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-2">
            Everything you need to maintain peak focus, study longer hours, and achieve your target goals.
          </p>
        </div>

        {/* 6 Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {cards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <div
                key={idx}
                id={`why-choose-card-${idx}`}
                className="bg-white p-5 sm:p-6 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition-shadow flex items-start space-x-4 group"
              >
                <div className={`p-3 rounded-lg border shrink-0 ${card.iconBg} group-hover:scale-105 transition-transform`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-900 text-base sm:text-lg mb-1 group-hover:text-indigo-700 transition-colors">
                    {card.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    {card.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom micro-CTA */}
        <div className="mt-8 text-center">
          <p className="text-xs sm:text-sm text-slate-500">
            Want to see our seat availability or experience the ambiance?{' '}
            <button
              onClick={onOpenRegister}
              className="text-indigo-700 font-bold underline hover:text-indigo-900 cursor-pointer"
            >
              Fill the online registration form now
            </button>
          </p>
        </div>

      </div>
    </section>
  );
};
