export type PageSection = 
  | 'home' 
  | 'fees' 
  | 'facilities' 
  | 'register' 
  | 'gallery' 
  | 'location' 
  | 'timings' 
  | 'offers' 
  | 'about' 
  | 'contact' 
  | 'faq';

export interface MembershipPlan {
  id: 'half-day' | 'full-day';
  name: string;
  fee: number;
  duration: string;
  badge?: string;
  popular?: boolean;
  timing: string;
  features: string[];
}

export interface Facility {
  id: string;
  title: string;
  description: string;
  iconName: string;
  badge?: string;
  color: string;
}

export interface Offer {
  id: string;
  title: string;
  discountBadge: string;
  description: string;
  eligibility: string;
  iconName: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'hall' | 'desks' | 'reception' | 'amenities';
  imageUrl: string;
  description: string;
}

export interface RegistrationFormData {
  fullName: string;
  mobile: string;
  email: string;
  dob: string;
  gender: 'Male' | 'Female' | 'Other' | 'Prefer not to say' | '';
  occupation: 'Student' | 'Working Professional' | 'Other' | '';
  examPurpose: string;
  plan: 'Half Day – ₹400' | 'Full Day – ₹600' | '';
  startDate: string;
  preferredTiming: 'Morning' | 'Afternoon' | 'Evening' | 'Full Day' | '';
  heardFrom: 'Google' | 'Instagram' | 'WhatsApp' | 'Friend' | 'Other' | '';
  message: string;
}

export interface SavedRegistration extends RegistrationFormData {
  id: string;
  submittedAt: string;
  status: 'Pending Verification' | 'Seat Confirmed';
}

export interface FaqItem {
  question: string;
  answer: string;
  category?: string;
}
