import { MembershipPlan, Facility, Offer, GalleryItem, FaqItem } from '../types';
import studyHallImg from '../assets/images/library_study_hall_1788633213780.jpg';
import deskViewImg from '../assets/images/library_desk_view_1788633230900.jpg';
import receptionImg from '../assets/images/library_reception_1788633249575.jpg';

export const LIBRARY_INFO = {
  name: 'AADHAY LIBRARY',
  ownerName: 'DEEPAK TALIYAN',
  ownerTitle: 'Founder & Owner',
  motto: 'Study • Focus • Success',
  tagline: 'A Peaceful, AC & Comfortable Self-Study Space in Meerut',
  phone: '9520200942',
  phoneFormatted: '+91 95202 00942',
  email: 'vk112desi@gmail.com',
  whatsappUrl: 'https://wa.me/919520200942?text=Hello%20Aadhay%20Library%2C%20I%20am%20interested%20in%20joining%20the%20library.%20Please%20let%20me%20know%20about%20seat%20availability.',
  address: 'Aadhay Library, Delhi Road / Near University Area, Meerut, Uttar Pradesh - 250002',
  city: 'Meerut, Uttar Pradesh',
  openingHours: 'Monday – Sunday: 6:00 AM – 10:00 PM',
  mapEmbedUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d111749.33614138096!2d77.6253457140625!3d28.984461799999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390c64f457b66325%3A0x42fed8be2337b60!2sMeerut%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin',
  googleMapsDirectionsUrl: 'https://www.google.com/maps/dir/?api=1&destination=Meerut+Uttar+Pradesh',
};

export const WHY_CHOOSE_US = [
  {
    id: 'ac',
    icon: 'Snowflake',
    title: 'Fully AC',
    description: 'Comfortable air-conditioned study environment maintained at ideal study temperature.',
    accent: 'indigo',
  },
  {
    id: 'water',
    icon: 'Droplets',
    title: 'Drinking Water',
    description: 'Clean RO drinking water facility available throughout the day for all students.',
    accent: 'blue',
  },
  {
    id: 'seating',
    icon: 'Armchair',
    title: 'Comfortable Seating',
    description: 'Dedicated ergonomic seating designed for long hours of focused self-study without fatigue.',
    accent: 'emerald',
  },
  {
    id: 'peace',
    icon: 'VolumeX',
    title: 'Peaceful Environment',
    description: 'Quiet, zero-distraction atmosphere strictly maintained for deep concentration.',
    accent: 'amber',
  },
  {
    id: 'study',
    icon: 'BookOpen',
    title: 'Study Friendly',
    description: 'Specially created for students and competitive-exam aspirants (UPSC, SSC, Banking, etc.).',
    accent: 'purple',
  },
  {
    id: 'reg',
    icon: 'Smartphone',
    title: 'Easy Registration',
    description: 'Fast online registration process to reserve your seat before visiting the library.',
    accent: 'rose',
  },
];

export const PLANS: MembershipPlan[] = [
  {
    id: 'half-day',
    name: 'Half Day',
    fee: 400,
    duration: 'per month',
    timing: 'Morning (6 AM - 2 PM) or Evening (2 PM - 10 PM)',
    popular: false,
    badge: 'Flexible Timing',
    features: [
      'Comfortable study seat',
      'AC facility',
      'Drinking water',
      'Peaceful study environment',
      'Morning or Evening shift choice',
      'Dedicated power socket at desk',
      'High-speed Wi-Fi access',
    ],
  },
  {
    id: 'full-day',
    name: 'Full Day',
    fee: 600,
    duration: 'per month',
    timing: 'Full Day Access: 6:00 AM – 10:00 PM (16 Hours)',
    popular: true,
    badge: 'Most Popular for Aspirants',
    features: [
      'Comfortable study seat (Dedicated spot)',
      'AC facility',
      'Drinking water',
      'Peaceful study environment',
      'Full-day study access (16 hrs/day)',
      'Priority seat reservation',
      'Personal charging point & high-speed Wi-Fi',
      'Open all 7 days (Monday - Sunday)',
    ],
  },
];

export const OFFERS: Offer[] = [
  {
    id: 'student',
    title: 'Student Discount',
    discountBadge: 'Student Benefit',
    description: 'Eligible students with valid college, university, or coaching ID receive special fee concessions.',
    eligibility: 'Show valid Student / Coaching ID during verification',
    iconName: 'GraduationCap',
  },
  {
    id: 'referral',
    title: 'Referral Offer',
    discountBadge: 'Friend Benefit',
    description: 'Invite your study partner or friend to enroll at Aadhay Library and both enjoy special membership benefits.',
    eligibility: 'Applicable when your referred friend confirms seat',
    iconName: 'Users',
  },
  {
    id: 'monthly',
    title: 'Monthly Membership Offer',
    discountBadge: 'Advance Booking',
    description: 'Commit to continuous preparation with our 3-month or 6-month advance membership plans for guaranteed savings.',
    eligibility: 'Applicable on quarterly or half-yearly advance fees',
    iconName: 'CalendarCheck',
  },
  {
    id: 'limited',
    title: 'Limited-Time New Member Offer',
    discountBadge: 'Welcome Bonus',
    description: 'New members joining this month get zero registration processing fee and priority desk selection.',
    eligibility: 'For all first-time online registrations',
    iconName: 'Flame',
  },
];

export const FACILITIES: Facility[] = [
  {
    id: '1',
    title: 'Fully AC',
    description: 'Comfortable air-conditioned climate control throughout hot summers and humid months.',
    iconName: 'Snowflake',
    badge: 'Climate Controlled',
    color: 'text-indigo-600 bg-indigo-50',
  },
  {
    id: '2',
    title: 'Drinking Water',
    description: 'Clean, multi-stage RO purified drinking water dispenser with normal and chilled options.',
    iconName: 'Droplets',
    badge: 'Pure RO Water',
    color: 'text-blue-600 bg-blue-50',
  },
  {
    id: '3',
    title: 'Comfortable Seating',
    description: 'Ergonomic high-back cushioned chairs designed specifically for 8+ hours of uninterrupted study.',
    iconName: 'Armchair',
    badge: 'Ergonomic Design',
    color: 'text-emerald-600 bg-emerald-50',
  },
  {
    id: '4',
    title: 'Proper Lighting',
    description: 'Anti-glare, eye-safe warm white illumination and individual reading lights to avoid eye strain.',
    iconName: 'Lightbulb',
    badge: 'Eye-Care Light',
    color: 'text-amber-600 bg-amber-50',
  },
  {
    id: '5',
    title: 'Charging Points',
    description: 'Dedicated multi-pin electric socket right on your personal cubicle for laptop, phone, or tablet.',
    iconName: 'Zap',
    badge: 'At Every Desk',
    color: 'text-yellow-600 bg-yellow-50',
  },
  {
    id: '6',
    title: 'High-Speed Wi-Fi',
    description: 'Uninterrupted fiber broadband connection for streaming video lectures, test series, and downloads.',
    iconName: 'Wifi',
    badge: 'Fiber Broadband',
    color: 'text-cyan-600 bg-cyan-50',
  },
  {
    id: '7',
    title: 'Safe Parking',
    description: 'Spacious and secure parking space for two-wheelers and bicycles with CCTV surveillance.',
    iconName: 'Car',
    badge: 'Free Parking',
    color: 'text-purple-600 bg-purple-50',
  },
  {
    id: '8',
    title: 'Self-Study Environment',
    description: 'Private cubicle partition dividers that ensure visual privacy and help you maintain peak focus.',
    iconName: 'BookOpen',
    badge: 'Personal Space',
    color: 'text-indigo-600 bg-indigo-50',
  },
  {
    id: '9',
    title: 'Silent / Peaceful Atmosphere',
    description: 'Strict zero-talking policy and silent mobile phone protocols enforced by floor supervisors.',
    iconName: 'VolumeX',
    badge: '100% Silence',
    color: 'text-rose-600 bg-rose-50',
  },
  {
    id: '10',
    title: 'Clean Washroom Facility',
    description: 'Separate, sanitized, and regularly maintained hygienic washroom for students.',
    iconName: 'Sparkles',
    badge: 'Hygienic',
    color: 'text-teal-600 bg-teal-50',
  },
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'g1',
    title: 'Silent Study Hall',
    category: 'hall',
    imageUrl: studyHallImg,
    description: 'Spacious, well-ventilated silent study hall with private wooden partitions and LED lighting.',
  },
  {
    id: 'g2',
    title: 'Individual Study Desk & Ergonomic Chair',
    category: 'desks',
    imageUrl: deskViewImg,
    description: 'Personal study desk equipped with individual power socket, reading light, and cushioned chair.',
  },
  {
    id: 'g3',
    title: 'Reception & Registration Desk',
    category: 'reception',
    imageUrl: receptionImg,
    description: 'Welcoming reception counter for quick inquiries, seat allocation, and visitor support.',
  },
  {
    id: 'g4',
    title: 'Air Conditioned Study Zone',
    category: 'hall',
    imageUrl: studyHallImg,
    description: 'Maintained at optimal temperature so you can study comfortably during extreme summers.',
  },
  {
    id: 'g5',
    title: 'Personal Study Desks with Charging',
    category: 'desks',
    imageUrl: deskViewImg,
    description: 'Dedicated space to place your laptop, books, and study notes comfortably.',
  },
  {
    id: 'g6',
    title: 'Clean Facility & Refreshment Area',
    category: 'amenities',
    imageUrl: receptionImg,
    description: 'Clean RO water dispenser station and sanitized facilities maintained daily.',
  },
];

export const FAQS: FaqItem[] = [
  {
    question: 'Registration kaise karein?',
    answer: 'Online registration form fill karein ya library par directly visit karein. Form submit karne par aapko instant registration details mil jayengi, jiske baad aap WhatsApp ya Call (9520200942) par confirm kar sakte hain.',
  },
  {
    question: 'Fees kitni hai?',
    answer: 'Aadhay Library mein do simple plans hain: Half Day plan sirf ₹400 per month hai, aur Full Day (6 AM to 10 PM) plan sirf ₹600 per month hai. Dono plans mein AC, drinking water aur comfortable seating included hai.',
  },
  {
    question: 'AC available hai?',
    answer: 'Yes, fully AC facility available hai. Hall mein balanced cooling maintain ki jaati hai taaki aapko padhai mein poora aaram mile.',
  },
  {
    question: 'Drinking water available hai?',
    answer: 'Yes, clean and pure RO drinking water facility available hai with both normal aur chilled drinking water options.',
  },
  {
    question: 'Online registration possible hai?',
    answer: 'Yes, hamari website par direct online registration form available hai. Aap ghar baithe apni details aur preferred plan select karke seat reserve kar sakte hain.',
  },
  {
    question: 'Seat availability kaise check karein?',
    answer: 'Website par registration form submit karne ke baad hamare team number 9520200942 par call ya WhatsApp karke apni preferred seat instantly confirm kar sakte hain.',
  },
  {
    question: 'Payment kaise karein?',
    answer: 'Aap online UPI (Google Pay, PhonePe, Paytm, BHIM), Cash, ya Direct Bank Transfer ke through fees pay kar sakte hain jab aap seat verification ke liye aate hain.',
  },
  {
    question: 'Library ki timings kya hain?',
    answer: 'Aadhay Library Monday se Sunday poore 7 din subah 6:00 AM se raat 10:00 PM tak open rehti hai. Morning shift 6 AM - 2 PM, Evening shift 2 PM - 10 PM, aur Full day members 6 AM se 10 PM tak study kar sakte hain.',
  },
  {
    question: 'Kya laptop aur mobile charging point har desk par hai?',
    answer: 'Haan, har individual study desk par dedicated electric power socket provide kiya gaya hai taaki aap online classes, mock tests aur study gadgets bina kisi issue ke use kar sakein.',
  },
];

export const TIMING_SCHEDULE = [
  {
    title: 'Morning Shift',
    time: '6:00 AM – 2:00 PM',
    duration: '8 Hours',
    description: 'Perfect for early risers, college students, and test series revision.',
    badge: 'Popular',
  },
  {
    title: 'Evening Shift',
    time: '2:00 PM – 10:00 PM',
    duration: '8 Hours',
    description: 'Ideal for candidates with afternoon or evening study routines.',
    badge: 'Peaceful',
  },
  {
    title: 'Full Day Access',
    time: '6:00 AM – 10:00 PM',
    duration: '16 Hours Non-Stop',
    description: 'Dedicated reserved seat all day with complete access to all facilities.',
    badge: 'Best Value',
  },
];
