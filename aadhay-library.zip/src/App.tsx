import React, { useState, useEffect } from 'react';
import { PageSection } from './types';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { WhyChooseUs } from './components/WhyChooseUs';
import { FeesSection } from './components/FeesSection';
import { OffersSection } from './components/OffersSection';
import { FacilitiesSection } from './components/FacilitiesSection';
import { RegistrationForm } from './components/RegistrationForm';
import { TimingsSection } from './components/TimingsSection';
import { GallerySection } from './components/GallerySection';
import { LocationSection } from './components/LocationSection';
import { AboutSection } from './components/AboutSection';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { PolicyModal } from './components/PolicyModal';
import { FloatingBar } from './components/FloatingBar';

export default function App() {
  const [activeSection, setActiveSection] = useState<PageSection>('home');
  const [selectedPlanForReg, setSelectedPlanForReg] = useState<'Half Day – ₹400' | 'Full Day – ₹600' | undefined>(undefined);
  const [policyModalType, setPolicyModalType] = useState<'privacy' | 'terms' | null>(null);

  // Scroll to section handler
  const handleNavigate = (section: PageSection) => {
    setActiveSection(section);
    const element = document.getElementById(`${section}-section`) || document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleOpenRegister = (plan?: 'Half Day – ₹400' | 'Full Day – ₹600') => {
    if (plan) {
      setSelectedPlanForReg(plan);
    }
    setActiveSection('register');
    const el = document.getElementById('register-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Observe scroll position to update active navbar link
  useEffect(() => {
    const handleScroll = () => {
      const sections: PageSection[] = ['home', 'fees', 'facilities', 'register', 'gallery', 'location', 'contact'];
      const scrollPos = window.scrollY + 200;

      for (let i = sections.length - 1; i >= 0; i--) {
        const sec = sections[i];
        const el = document.getElementById(`${sec}-section`) || document.getElementById(sec);
        if (el && el.offsetTop <= scrollPos) {
          setActiveSection(sec);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 selection:bg-indigo-600 selection:text-white">
      {/* Navigation Header */}
      <Header
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onOpenRegister={handleOpenRegister}
      />

      {/* Main Page Flow */}
      <main className="flex-1 flex flex-col">
        {/* PAGE 1: Home & Hero */}
        <div id="home-section">
          <HeroSection
            onNavigate={handleNavigate}
            onOpenRegister={handleOpenRegister}
          />
        </div>

        {/* WHY CHOOSE US (6 Cards) */}
        <WhyChooseUs onOpenRegister={() => handleOpenRegister()} />

        {/* PAGE 2: Fees Structure */}
        <FeesSection onOpenRegister={handleOpenRegister} />

        {/* PAGE 7: Facilities */}
        <FacilitiesSection />

        {/* PAGE 4: Online Registration Form */}
        <RegistrationForm
          initialPlan={selectedPlanForReg}
          onPlanConsumed={() => setSelectedPlanForReg(undefined)}
        />

        {/* PAGE 3: Offers & Discounts */}
        <OffersSection onOpenRegister={() => handleOpenRegister()} />

        {/* PAGE 6: Library Timings */}
        <TimingsSection />

        {/* PAGE 8: Gallery */}
        <GallerySection />

        {/* PAGE 5: Location & Map */}
        <LocationSection />

        {/* PAGE 10: About Us */}
        <AboutSection />

        {/* PAGE 11: FAQ */}
        <FaqSection />

        {/* PAGE 9: Contact Us */}
        <ContactSection onOpenRegister={() => handleOpenRegister()} />
      </main>

      {/* Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenPolicy={(type) => setPolicyModalType(type)}
      />

      {/* Floating Action Bar */}
      <FloatingBar onOpenRegister={() => handleOpenRegister()} />

      {/* Legal & Terms Modals (Pages 12 & 13) */}
      <PolicyModal
        type={policyModalType}
        onClose={() => setPolicyModalType(null)}
      />
    </div>
  );
}
